face/ emotion detector using device camera

# Run npm install
# then Run npm start
